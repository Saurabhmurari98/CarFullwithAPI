import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CarDetailServiceService {

  private apiUrl = 'https://localhost:44314/api/CarDetails/';  

  constructor(private http: HttpClient) {}


  addCarDetails(carData: FormData): Observable<any> {
    return this.http.post<any>(this.apiUrl + 'upload', carData); 
  }
  getCarDetails(): Observable<CarDetails[]> {
    return this.http.get<CarDetails[]>(this.apiUrl +'all');
  }
  getCarDetailsById(id:number): Observable<CarDetails[]> {
    return this.http.get<CarDetails[]>(`${this.apiUrl}${id}`);
  }
  updateCarDetails(id: number, data: FormData) {
    return this.http.put(`${this.apiUrl}update/${id}`, data);
  }
  downloadCarDetails(): Observable<Blob> {
    return this.http.get(this.apiUrl + 'download', { responseType: 'blob' });
  }
  downloadCarDetailsById(id: number): Observable<Blob> {
    return this.http.get(`${this.apiUrl}download/${id}`, { responseType: 'blob' });
  }
  delete(id:number){
    return this.http.delete(`${this.apiUrl}${id}`);
  }
}
export interface CarDetails {
  Id: number;
  CarMaker: string;
  CarModel: string;
  CarType: string;
  CubicCapacity: string;
  NoOfWheels: number;
  ManufactureYear: number;
  NoOfPassengers: number;
  Description: string;
  CarPic1: string;
  CarPic2: string;
  CarPic3: string;
  Filename: string;
}
