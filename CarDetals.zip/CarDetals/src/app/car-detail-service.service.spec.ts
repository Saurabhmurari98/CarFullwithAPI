import { TestBed } from '@angular/core/testing';

import { CarDetailServiceService } from './car-detail-service.service';

describe('CarDetailServiceService', () => {
  let service: CarDetailServiceService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(CarDetailServiceService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
