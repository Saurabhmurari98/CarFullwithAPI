import { ChangeDetectorRef, Component } from '@angular/core';
import { CarDetailServiceService } from './car-detail-service.service';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { DomSanitizer } from '@angular/platform-browser';

@Component({
  selector: 'app-root',
  imports: [CommonModule, FormsModule, ReactiveFormsModule],
  templateUrl: './app.component.html',
  styleUrl: './app.component.css',
})
export class AppComponent {
  title = 'CarDetals_Angular';

  dataSource: any[] = [];
  selectedCar: boolean = false;
  id: any;
  maker: any;
  type: any;
  model: any;
  year: any;
  cubic: any;
  NoOfWheels: any;
  NoOfPassengers: any;
  Description: any;
  Filename: any;
  CarPic1!: File;
  CarPic2!: File;
  CarPic3!: File;
  [key: string]: any;
  ImageUrl = 'https://localhost:44314';
  DataPdf: any[] = [];
  text:any;
  btntext:any;

  constructor(
    private carDetailsService: CarDetailServiceService,
    private sanatizer: DomSanitizer,
    private cdRef: ChangeDetectorRef
  ) {}

  ngOnInit(): void {
    this.getData();
  }
  getData() {
    this.carDetailsService.getCarDetails().subscribe((data) => {
      this.dataSource = data;
      this.dataSource.forEach((car: any) => {
        car.carPic1 = this.sanatizer.bypassSecurityTrustUrl(
          this.ImageUrl + car.carPic1
        );
        car.carPic2 = this.sanatizer.bypassSecurityTrustUrl(
          this.ImageUrl + car.carPic2
        );
        car.carPic3 = this.sanatizer.bypassSecurityTrustUrl(
          this.ImageUrl + car.carPic3
        );
      });
    });
  }
  editCar(car: any): void {
    this.selectedCar = true;
    this.text = 'Edit';
    this.btntext = 'Update';
    this.id = car.id;
    this.maker = car.carMaker;
    this.type = car.carType;
    this.model = car.carModel;
    this.year = car.manufactureYear;
    this.cubic = car.cubicCapacity;
    this.NoOfWheels = car.noOfWheels;
    this.NoOfPassengers = car.noOfPassengers;
    this.Description = car.description;
    this.Filename = car.fileName;
    car.CarPic1 = car.carPic1;
    car.CarPic2 = car.carPic2;
    car.CarPic3 = car.carPic3;
  }
  onCancel(): void {
    this.selectedCar = false;
  }
  addCar() {
    this.selectedCar = true;
    this.text = 'Add';
    this.btntext = 'Save';
    this.id = null;
    this.maker = '';
    this.model = '';
    this.type = '';
    this.year = null;
    this.cubic = null;
    this.NoOfWheels = null;
    this.NoOfPassengers = null;
    this.Description = '';
    this.Filename = '';
  }
  onSubmit() {
    const updatedCar = new FormData();
    updatedCar.append('CarMaker', this.maker);
    updatedCar.append('CarModel', this.model);
    updatedCar.append('CarType', this.type);
    updatedCar.append('ManufactureYear', this.year);
    updatedCar.append('CubicCapacity', this.cubic);
    updatedCar.append('NoOfWheels', this.NoOfWheels);
    updatedCar.append('NoOfPassengers', this.NoOfPassengers);
    updatedCar.append('Description', this.Description);
    updatedCar.append('Filename', this.Filename);

    if (this.CarPic1) {
      updatedCar.append('CarPic1', this.CarPic1, this.CarPic1.name);
    }
    if (this.CarPic2) {
      updatedCar.append('CarPic2', this.CarPic2, this.CarPic2.name);
    }
    if (this.CarPic3) {
      updatedCar.append('CarPic3', this.CarPic3, this.CarPic3.name);
    }

    if (this.id) {
      this.carDetailsService
        .updateCarDetails(this.id, updatedCar)
        .subscribe(() => {
          this.selectedCar = false;
          this.getData();
        });
    } else {
      this.carDetailsService.addCarDetails(updatedCar).subscribe(() => {
        this.selectedCar = false;
        this.getData();
      });
    }
  }
  onFileSelected(event: any, imageField: string) {
    const file = event.target.files[0];
    if (file) {
      this[imageField] = file;
    }
  }

  downloadAll() {
    this.carDetailsService.downloadCarDetails().subscribe((data: Blob) => {
      const blob = new Blob([data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Allcar_details.pdf'; 
      document.body.appendChild(a);
      a.click(); 
      document.body.removeChild(a); 
      window.URL.revokeObjectURL(url); 
      console.log('Download successfully');
    }, error => {
      console.error('Download error:', error);
    });
  }


  download(car: any) {
    this.carDetailsService.downloadCarDetailsById(car.id).subscribe((data: Blob) => {
      const blob = new Blob([data], { type: 'application/pdf' });
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = car.fileName + '.pdf'; 
      document.body.appendChild(a);
      a.click(); 
      document.body.removeChild(a); 
      window.URL.revokeObjectURL(url); 
      console.log('Download successfully');
    }, error => {
      console.error('Download error:', error);
    });
  }

  delete(car:any){
    alert('Are you sure you want to delete this car?');
    this.carDetailsService.delete(car.id).subscribe(()=>{
      this.getData();
    });
  }
}
